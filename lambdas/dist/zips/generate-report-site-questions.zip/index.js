const AWS = require("aws-sdk");
const slackApi = require("./slackApiWrapers");
const queryString = require("querystring");

const possibleStates = {
  0: {
    stateGroup: "accreditation",
    text: "Do you have the proper accreditation for a farm?",
    optionType: "twoChoice",
    optionName: "farmAcred",
    nextState: 1
  },
  done: {}
};

function generateQuestionPrompt(state, user) {
  const currentState = possibleStates[state];
  console.log("here is our current state", currentState);
  let baseTemplate = {
    fallback: "You don't know what to do?",
    callback_id: user + ":" + currentState.nextState,
    color: "#3AA3E3",
    attachment_type: "default",
    text: currentState.text
  };
  switch (currentState.optionType) {
    case "twoChoice":
      baseTemplate.actions = [
        {
          name: currentState.optionName,
          text: "Yes",
          type: "button",
          value: 0
        },
        {
          name: currentState.optionName,
          text: "No",
          type: "button",
          value: 1
        }
      ];
      break;
    default:
      break;
  }
  return [baseTemplate];
}

function postInteractiveStateMessage(state, user, channel, text) {
  console.log("entered start state with user", user);
  const baseTemplate = generateQuestionPrompt(state, user);
  console.log("here is our base template.", baseTemplate);
  return slackApi.postMessage(text, channel, baseTemplate);
}

exports.handler = (event, context, callback) => {
  slackApi.setBotToken(process.env.BOT_TOKEN);
  if (event.state === 0 && event.channel_id) {
    postInteractiveStateMessage(
      0,
      event.user_name,
      event.channel_id,
      "Hey " + event.user_name + " i'll be more than happy to assist."
    ).then(() => {
      console.log("here? we finished sending");
      callback();
    });
  } else {
    console.log("we have been transfered here with the payload", event);
    callback();
  }
};
